﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'vi', {
	auto: 'Tự động',
	bgColorTitle: 'Màu nền',
	colors: {
		'000': 'Đen',
		'800000': 'Maroon',
		'8B4513': 'Saddle Brown',
		'2F4F4F': 'Dark Slate Gray',
		'008080': 'Teal',
		'000080': 'Navy',
		'4B0082': 'Indigo',
		'696969': 'Dark Gray',
		B22222: 'Fire Brick',
		A52A2A: 'Nâu',
		DAA520: 'Golden Rod',
		'006400': 'Dark Green',
		'40E0D0': 'Turquoise',
		'0000CD': 'Medium Blue',
		'800080': 'Purple',
		'808080': 'Xám',
		F00: 'Đỏ',
		FF8C00: 'Dark Orange',
		FFD700: 'Vàng',
		'008000': 'Xanh lá cây',
		'0FF': 'Cyan',
		'00F': 'Xanh da trời',
		EE82EE: 'Tím',
		A9A9A9: 'Xám tối',
		FFA07A: 'Light Salmon',
		FFA500: 'Màu cam',
		FFFF00: 'Vàng',
		'00FF00': 'Lime',
		AFEEEE: 'Pale Turquoise',
		ADD8E6: 'Light Blue',
		DDA0DD: 'Plum',
		D3D3D3: 'Light Grey',
		FFF0F5: 'Lavender Blush',
		FAEBD7: 'Antique White',
		FFFFE0: 'Light Yellow',
		F0FFF0: 'Honeydew',
		F0FFFF: 'Azure',
		F0F8FF: 'Alice Blue',
		E6E6FA: 'Lavender',
		FFF: 'Trắng',
		'1ABC9C': 'Xanh lơ đậm',
		'2ECC71': 'Xanh lục bảo',
		'3498DB': 'Xanh dương sáng',
		'9B59B6': 'Tím thạch anh',
		'4E5F70': 'Xanh dương xám',
		'F1C40F': 'Vàng rực',
		'16A085': 'Xanh lơ đạm',
		'27AE60': 'Xanh lục bảo đậm',
		'2980B9': 'Xanh biển đậm',
		'8E44AD': 'Tím đậm',
		'2C3E50': 'Xanh dương nhạt',
		'F39C12': 'Cam',
		'E67E22': 'Cà rốt',
		'E74C3C': 'Đỏ tái',
		'ECF0F1': 'Bạc sáng',
		'95A5A6': 'Xanh lơ xám nhạt',
		'DDD': 'Xám nhạt',
		'D35400': 'Bí ngô',
		'C0392B': 'Đỏ rực',
		'BDC3C7': 'Bạc',
		'7F8C8D': 'Xanh lơ xám',
		'999': 'Xám đen'
	},
	more: 'Màu khác...',
	panelTitle: 'Màu sắc',
	textColorTitle: 'Màu chữ'
} );
