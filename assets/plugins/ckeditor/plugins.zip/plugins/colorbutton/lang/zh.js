﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'zh', {
	auto: '自動',
	bgColorTitle: '背景顏色',
	colors: {
		'000': '黑色',
		'800000': '栗色',
		'8B4513': '鞍褐色',
		'2F4F4F': '暗瓦灰色',
		'008080': '水壓色',
		'000080': '丈青澀',
		'4B0082': '靛青',
		'696969': '深灰色',
		B22222: '磚紅色',
		A52A2A: '褐色',
		DAA520: '金黃色',
		'006400': '深綠色',
		'40E0D0': '青綠色',
		'0000CD': '藍色',
		'800080': '紫色',
		'808080': '灰色',
		F00: '紅色',
		FF8C00: '深橘色',
		FFD700: '金色',
		'008000': '綠色',
		'0FF': '青色',
		'00F': '藍色',
		EE82EE: '紫色',
		A9A9A9: '暗灰色',
		FFA07A: '亮鮭紅',
		FFA500: '橘色',
		FFFF00: '黃色',
		'00FF00': '鮮綠色',
		AFEEEE: '綠松色',
		ADD8E6: '淺藍色',
		DDA0DD: '枚紅色',
		D3D3D3: '淺灰色',
		FFF0F5: '淺紫色',
		FAEBD7: '骨董白',
		FFFFE0: '淺黃色',
		F0FFF0: '蜜瓜綠',
		F0FFFF: '天藍色',
		F0F8FF: '愛麗斯蘭',
		E6E6FA: '淺紫色',
		FFF: '白色',
		'1ABC9C': '深青色',
		'2ECC71': '翠綠色',
		'3498DB': '亮藍色',
		'9B59B6': '紫色',
		'4E5F70': '藍灰色',
		'F1C40F': '鮮黃色',
		'16A085': '暗青色',
		'27AE60': '暗綠色',
		'2980B9': '深藍色',
		'8E44AD': '暗紫色',
		'2C3E50': '不飽和藍色',
		'F39C12': '橘色',
		'E67E22': '胡蘿蔔色',
		'E74C3C': '淡紅色',
		'ECF0F1': '亮銀色',
		'95A5A6': '淺灰青色',
		'DDD': '淺灰色',
		'D35400': '南瓜色',
		'C0392B': '深紅色',
		'BDC3C7': '銀色',
		'7F8C8D': '灰青色',
		'999': '深灰色'
	},
	more: '更多顏色',
	panelTitle: '顏色',
	textColorTitle: '文字顏色'
} );
