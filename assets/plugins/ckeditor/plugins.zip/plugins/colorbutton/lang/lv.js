﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'lv', {
	auto: 'Automātiska',
	bgColorTitle: 'Fona krāsa',
	colors: {
		'000': 'Melns',
		'800000': 'Sarkanbrūns',
		'8B4513': 'Sedlu brūns',
		'2F4F4F': 'Tumšas tāfeles pelēks',
		'008080': 'Zili-zaļš',
		'000080': 'Jūras',
		'4B0082': 'Indigo',
		'696969': 'Tumši pelēks',
		B22222: 'Ķieģeļsarkans',
		A52A2A: 'Brūns',
		DAA520: 'Zelta',
		'006400': 'Tumši zaļš',
		'40E0D0': 'Tirkīzs',
		'0000CD': 'Vidēji zils',
		'800080': 'Purpurs',
		'808080': 'Pelēks',
		F00: 'Sarkans',
		FF8C00: 'Tumši oranžs',
		FFD700: 'Zelta',
		'008000': 'Zaļš',
		'0FF': 'Tumšzils',
		'00F': 'Zils',
		EE82EE: 'Violets',
		A9A9A9: 'Pelēks',
		FFA07A: 'Gaiši laškrāsas',
		FFA500: 'Oranžs',
		FFFF00: 'Dzeltens',
		'00FF00': 'Laima',
		AFEEEE: 'Gaiši tirkīza',
		ADD8E6: 'Gaiši zils',
		DDA0DD: 'Plūmju',
		D3D3D3: 'Gaiši pelēks',
		FFF0F5: 'Lavandas sārts',
		FAEBD7: 'Antīki balts',
		FFFFE0: 'Gaiši dzeltens',
		F0FFF0: 'Meduspile',
		F0FFFF: 'Debesszils',
		F0F8FF: 'Alises zils',
		E6E6FA: 'Lavanda',
		FFF: 'Balts',
		'1ABC9C': 'Spēcīgs ciāna',
		'2ECC71': 'Smaragds',
		'3498DB': 'Koši zils',
		'9B59B6': 'Ametists',
		'4E5F70': 'Pelēkzils',
		'F1C40F': 'Spilgti dzeltens',
		'16A085': 'Tumšs ciāna',
		'27AE60': 'Tumšs smaragds',
		'2980B9': 'Spēcīgi zils',
		'8E44AD': 'Tumši violets',
		'2C3E50': 'Bāli zils',
		'F39C12': 'Apelsīnu',
		'E67E22': 'Burkānu',
		'E74C3C': 'Blāvi sarkans',
		'ECF0F1': 'Spilgti sudraba',
		'95A5A6': 'Gaišs pelēki ciāna',
		'DDD': 'Gaiši pelēks',
		'D35400': 'Ķirbja',
		'C0392B': 'Spēcīgi sarkans',
		'BDC3C7': 'Sudraba',
		'7F8C8D': 'Pelēcīgs ciāna',
		'999': 'Tumši pelēks'
	},
	more: 'Plašāka palete...',
	panelTitle: 'Krāsa',
	textColorTitle: 'Teksta krāsa'
} );
