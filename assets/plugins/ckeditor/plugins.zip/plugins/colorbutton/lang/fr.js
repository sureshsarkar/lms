﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'fr', {
	auto: 'Automatique',
	bgColorTitle: 'Couleur d\'arrière-plan',
	colors: {
		'000': 'Noir',
		'800000': 'Marron',
		'8B4513': 'Brun de selle',
		'2F4F4F': 'Gris sombre d\'ardoise',
		'008080': 'Canard',
		'000080': 'Bleu marine',
		'4B0082': 'Indigo',
		'696969': 'Gris foncé',
		B22222: 'Rouge brique',
		A52A2A: 'Brun',
		DAA520: 'Or terni',
		'006400': 'Vert foncé',
		'40E0D0': 'Turquoise',
		'0000CD': 'Bleu royal',
		'800080': 'Violet',
		'808080': 'Gris',
		F00: 'Rouge',
		FF8C00: 'Orange foncé',
		FFD700: 'Or',
		'008000': 'Vert',
		'0FF': 'Cyan',
		'00F': 'Bleu',
		EE82EE: 'Violet',
		A9A9A9: 'Gris tamisé',
		FFA07A: 'Saumon clair',
		FFA500: 'Orange',
		FFFF00: 'Jaune',
		'00FF00': 'Lime',
		AFEEEE: 'Turquoise clair',
		ADD8E6: 'Bleu clair',
		DDA0DD: 'Prune',
		D3D3D3: 'Gris clair',
		FFF0F5: 'Fard lavande',
		FAEBD7: 'Blanc antique',
		FFFFE0: 'Jaune clair',
		F0FFF0: 'Vert rosée',
		F0FFFF: 'Azur',
		F0F8FF: 'Bleu Alice',
		E6E6FA: 'Lavande',
		FFF: 'Blanc',
		'1ABC9C': 'Cyan dur',
		'2ECC71': 'Émeraude',
		'3498DB': 'Bleu brillant',
		'9B59B6': 'Améthyste',
		'4E5F70': 'Bleu-gris',
		'F1C40F': 'Jaune vif',
		'16A085': 'Cyan foncé',
		'27AE60': 'Émeraude foncée',
		'2980B9': 'Bleu dur',
		'8E44AD': 'Violet foncé',
		'2C3E50': 'Bleu désaturé',
		'F39C12': 'Orange',
		'E67E22': 'Carotte',
		'E74C3C': 'Rouge pâle',
		'ECF0F1': 'Argent brillant',
		'95A5A6': 'Cyan-gris clair',
		'DDD': 'Gris clair',
		'D35400': 'Citrouille',
		'C0392B': 'Rouge dur',
		'BDC3C7': 'Argent',
		'7F8C8D': 'Cyan-gris',
		'999': 'Gris foncé'
	},
	more: 'Plus de couleurs...',
	panelTitle: 'Couleurs',
	textColorTitle: 'Couleur du texte'
} );
