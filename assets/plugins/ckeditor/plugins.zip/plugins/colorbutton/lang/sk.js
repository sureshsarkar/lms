﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'sk', {
	auto: 'Automaticky',
	bgColorTitle: 'Farba pozadia',
	colors: {
		'000': 'Čierna',
		'800000': 'Gaštanová',
		'8B4513': 'Sedlová hnedá',
		'2F4F4F': 'Tmavo bridlicovo sivá',
		'008080': 'Modrozelená',
		'000080': 'Tmavomodrá',
		'4B0082': 'Indigo',
		'696969': 'Tmavá sivá',
		B22222: 'Ohňová tehlová',
		A52A2A: 'Hnedá',
		DAA520: 'Zlatobyľ',
		'006400': 'Tmavá zelená',
		'40E0D0': 'Tyrkysová',
		'0000CD': 'Stredná modrá',
		'800080': 'Purpurová',
		'808080': 'Sivá',
		F00: 'Červená',
		FF8C00: 'Tmavá oranžová',
		FFD700: 'Zlatá',
		'008000': 'Zelená',
		'0FF': 'Azúrová',
		'00F': 'Modrá',
		EE82EE: 'Fialová',
		A9A9A9: 'Tmavá sivá',
		FFA07A: 'Svetlá lososová',
		FFA500: 'Oranžová',
		FFFF00: 'Žltá',
		'00FF00': 'Vápenná',
		AFEEEE: 'Svetlá tyrkysová',
		ADD8E6: 'Svetlá modrá',
		DDA0DD: 'Slivková',
		D3D3D3: 'Svetlá sivá',
		FFF0F5: 'Levanduľovo červená',
		FAEBD7: 'Antická biela',
		FFFFE0: 'Svetlá žltá',
		F0FFF0: 'Medová',
		F0FFFF: 'Azúrová',
		F0F8FF: 'Alicovo modrá',
		E6E6FA: 'Levanduľová',
		FFF: 'Biela',
		'1ABC9C': 'Silno tyrkysová',
		'2ECC71': 'Smaragdová',
		'3498DB': 'Svetlo modrá',
		'9B59B6': 'Ametystová',
		'4E5F70': 'Sivo modrá',
		'F1C40F': 'Sýto žltá',
		'16A085': 'Tmavo tyrkysová',
		'27AE60': 'Tmavo smaragdová',
		'2980B9': 'Silno modrá',
		'8E44AD': 'Tmavo fialová',
		'2C3E50': 'Nesýto modrá',
		'F39C12': 'Oranžová',
		'E67E22': 'Mrkvová',
		'E74C3C': 'Bledo červená',
		'ECF0F1': 'Svetlá bronzová',
		'95A5A6': 'Svetlá sivo-tyrkysová',
		'DDD': 'Svetlo sivá',
		'D35400': 'Tekvicová',
		'C0392B': 'Silno červená',
		'BDC3C7': 'Strieborná',
		'7F8C8D': 'Sivo tyrkysová',
		'999': 'Tmavo sivá'
	},
	more: 'Viac farieb...',
	panelTitle: 'Farby',
	textColorTitle: 'Farba textu'
} );
