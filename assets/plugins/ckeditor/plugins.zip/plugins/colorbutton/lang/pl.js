﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'pl', {
	auto: 'Automatycznie',
	bgColorTitle: 'Kolor tła',
	colors: {
		'000': 'Czarny',
		'800000': 'Kasztanowy',
		'8B4513': 'Czekoladowy',
		'2F4F4F': 'Ciemnografitowy',
		'008080': 'Morski',
		'000080': 'Granatowy',
		'4B0082': 'Indygo',
		'696969': 'Ciemnoszary',
		B22222: 'Czerwień żelazowa',
		A52A2A: 'Brązowy',
		DAA520: 'Ciemnozłoty',
		'006400': 'Ciemnozielony',
		'40E0D0': 'Turkusowy',
		'0000CD': 'Ciemnoniebieski',
		'800080': 'Purpurowy',
		'808080': 'Szary',
		F00: 'Czerwony',
		FF8C00: 'Ciemnopomarańczowy',
		FFD700: 'Złoty',
		'008000': 'Zielony',
		'0FF': 'Cyjan',
		'00F': 'Niebieski',
		EE82EE: 'Fioletowy',
		A9A9A9: 'Przygaszony szary',
		FFA07A: 'Łososiowy',
		FFA500: 'Pomarańczowy',
		FFFF00: 'Żółty',
		'00FF00': 'Limonkowy',
		AFEEEE: 'Bladoturkusowy',
		ADD8E6: 'Jasnoniebieski',
		DDA0DD: 'Śliwkowy',
		D3D3D3: 'Jasnoszary',
		FFF0F5: 'Jasnolawendowy',
		FAEBD7: 'Kremowobiały',
		FFFFE0: 'Jasnożółty',
		F0FFF0: 'Bladozielony',
		F0FFFF: 'Jasnolazurowy',
		F0F8FF: 'Jasnobłękitny',
		E6E6FA: 'Lawendowy',
		FFF: 'Biały',
		'1ABC9C': 'Cyjan',
		'2ECC71': 'Szmaragdowy',
		'3498DB': 'Jasnoniebieski',
		'9B59B6': 'Ametystowy',
		'4E5F70': 'Szaroniebieski',
		'F1C40F': 'Żółty',
		'16A085': 'Ciemny cyjan',
		'27AE60': 'Ciemnoszmaragdowy',
		'2980B9': 'Ciemnoniebieski',
		'8E44AD': 'Ciemnofioletowy',
		'2C3E50': 'Nienasycony niebieski',
		'F39C12': 'Pomarańczowy',
		'E67E22': 'Marchewkowy',
		'E74C3C': 'Bladoczerwony',
		'ECF0F1': 'Jasnosrebrny',
		'95A5A6': 'Szarocyjanowy',
		'DDD': 'Jasnoszary',
		'D35400': 'Dyniowy',
		'C0392B': 'Ciemnoczerwony',
		'BDC3C7': 'Srebrny',
		'7F8C8D': 'Szarawy cyjan',
		'999': 'Ciemnoszary'
	},
	more: 'Więcej kolorów...',
	panelTitle: 'Kolory',
	textColorTitle: 'Kolor tekstu'
} );
