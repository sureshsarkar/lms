﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'pt-br', {
	auto: 'Automático',
	bgColorTitle: 'Cor do Plano de Fundo',
	colors: {
		'000': 'Preto',
		'800000': 'Foquete',
		'8B4513': 'Marrom 1',
		'2F4F4F': 'Cinza 1',
		'008080': 'Cerceta',
		'000080': 'Azul Marinho',
		'4B0082': 'Índigo',
		'696969': 'Cinza 2',
		B22222: 'Tijolo de Fogo',
		A52A2A: 'Marrom 2',
		DAA520: 'Vara Dourada',
		'006400': 'Verde Escuro',
		'40E0D0': 'Turquesa',
		'0000CD': 'Azul Médio',
		'800080': 'Roxo',
		'808080': 'Cinza 3',
		F00: 'Vermelho',
		FF8C00: 'Laranja Escuro',
		FFD700: 'Dourado',
		'008000': 'Verde',
		'0FF': 'Ciano',
		'00F': 'Azul',
		EE82EE: 'Violeta',
		A9A9A9: 'Cinza Escuro',
		FFA07A: 'Salmão Claro',
		FFA500: 'Laranja',
		FFFF00: 'Amarelo',
		'00FF00': 'Lima',
		AFEEEE: 'Turquesa Pálido',
		ADD8E6: 'Azul Claro',
		DDA0DD: 'Ameixa',
		D3D3D3: 'Cinza Claro',
		FFF0F5: 'Lavanda 1',
		FAEBD7: 'Branco Antiguidade',
		FFFFE0: 'Amarelo Claro',
		F0FFF0: 'Orvalho',
		F0FFFF: 'Azure',
		F0F8FF: 'Azul Alice',
		E6E6FA: 'Lavanda 2',
		FFF: 'Branco',
		'1ABC9C': 'Ciano Forte',
		'2ECC71': 'Esmeralda',
		'3498DB': 'Azul Brilhante',
		'9B59B6': 'Ametista',
		'4E5F70': 'Azul acinzentado',
		'F1C40F': 'Amarelo Vívido',
		'16A085': 'Ciano Escuro',
		'27AE60': 'Esmeralda Escura',
		'2980B9': 'Azul Forte',
		'8E44AD': 'Violeta Escura',
		'2C3E50': 'Azul Dessaturado',
		'F39C12': 'Laranja',
		'E67E22': 'Laranja Cenoura',
		'E74C3C': 'Vermelho Pálido',
		'ECF0F1': 'Prata Brilhante',
		'95A5A6': 'Ciano Acinzentado Claro ',
		'DDD': 'Cinza Claro',
		'D35400': 'Abóbora',
		'C0392B': 'Vermelho Forte',
		'BDC3C7': 'Prata',
		'7F8C8D': 'Ciano Acinzentado',
		'999': 'Cinza Escuro'
	},
	more: 'Mais Cores...',
	panelTitle: 'Cores',
	textColorTitle: 'Cor do Texto'
} );
