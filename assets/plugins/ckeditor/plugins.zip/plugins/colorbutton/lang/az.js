﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'az', {
	auto: 'Avtomatik',
	bgColorTitle: 'Doldurma rəngi',
	colors: {
		'000': 'Qara',
		'800000': 'Şabalıdı',
		'8B4513': 'Açıq şabalı',
		'2F4F4F': 'Açıq boz',
		'008080': 'Firuzəyi göy',
		'000080': 'Tünd göy',
		'4B0082': 'İndigo',
		'696969': 'Tünd boz',
		B22222: 'Kərpiç',
		A52A2A: 'Şabalıdı',
		DAA520: 'Qızıl ağcaqayın',
		'006400': 'Tünd yaşıl',
		'40E0D0': 'Firuzəyi',
		'0000CD': 'Göy',
		'800080': 'Bənövşəyi',
		'808080': 'Boz',
		F00: 'Qırmızı',
		FF8C00: 'Tünd narıncı',
		FFD700: 'Qızılı',
		'008000': 'Yaşıl',
		'0FF': 'Mavi',
		'00F': 'Göy',
		EE82EE: 'Açıq bənövşəyi',
		A9A9A9: 'Asfalt rəngi',
		FFA07A: 'Qızılbalıq',
		FFA500: 'Narıncı',
		FFFF00: 'Sarı',
		'00FF00': 'Laym',
		AFEEEE: 'Acıq firuzəyi',
		ADD8E6: 'Acıq göy',
		DDA0DD: 'Gavalı',
		D3D3D3: 'Acıq boz',
		FFF0F5: 'Yasəmən',
		FAEBD7: 'Kağız',
		FFFFE0: 'Acıq sarı',
		F0FFF0: 'Yemişi',
		F0FFFF: 'Gömgöy',
		F0F8FF: 'Solğun göy',
		E6E6FA: 'Lavanda',
		FFF: 'Ağ',
		'1ABC9C': 'Güclü mavi',
		'2ECC71': 'Zümrüd',
		'3498DB': 'Parlaq göy',
		'9B59B6': 'Ametist',
		'4E5F70': 'Bozlu göy',
		'F1C40F': 'Sapsarı',
		'16A085': 'Tünd mavi',
		'27AE60': 'Tünd zümrüd',
		'2980B9': 'Güclü göy',
		'8E44AD': 'Tünd bənövşəyi',
		'2C3E50': 'Rəngsiz göy',
		'F39C12': 'Narıncı',
		'E67E22': 'Yerkökülü',
		'E74C3C': 'Solğun qırmızı',
		'ECF0F1': 'Parlaq gümüşü',
		'95A5A6': 'Acıq bozlu mavi',
		'DDD': 'Acıq boz',
		'D35400': 'Balqabaqlı',
		'C0392B': 'Güclü qırmızı',
		'BDC3C7': 'Gümüşü',
		'7F8C8D': 'Bozlu mavi',
		'999': 'Tünd boz'
	},
	more: 'Digər rənglər...',
	panelTitle: 'Rənglər',
	textColorTitle: 'Mətnin rəngi'
} );
