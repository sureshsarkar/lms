﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'da', {
	auto: 'Automatisk',
	bgColorTitle: 'Baggrundsfarve',
	colors: {
		'000': 'Sort',
		'800000': 'Mørkerød',
		'8B4513': 'Mørk orange',
		'2F4F4F': 'Mørk skifer grå',
		'008080': 'Turkis',
		'000080': 'Marine',
		'4B0082': 'Indigo',
		'696969': 'Mørkegrå',
		B22222: 'Scarlet / Rød',
		A52A2A: 'Brun',
		DAA520: 'Guld',
		'006400': 'Mørkegrøn',
		'40E0D0': 'Turkis',
		'0000CD': 'Mellemblå',
		'800080': 'Lilla',
		'808080': 'Grå',
		F00: 'Rød',
		FF8C00: 'Mørk orange',
		FFD700: 'Guld',
		'008000': 'Grøn',
		'0FF': 'Cyan',
		'00F': 'Blå',
		EE82EE: 'Violet',
		A9A9A9: 'Matgrå',
		FFA07A: 'Laksefarve',
		FFA500: 'Orange',
		FFFF00: 'Gul',
		'00FF00': 'Lime',
		AFEEEE: 'Mat turkis',
		ADD8E6: 'Lyseblå',
		DDA0DD: 'Mørkerød',
		D3D3D3: 'Lysegrå',
		FFF0F5: 'Lavendelrød',
		FAEBD7: 'Antikhvid',
		FFFFE0: 'Lysegul',
		F0FFF0: 'Gul / Beige',
		F0FFFF: 'Himmeblå',
		F0F8FF: 'Alice blue',
		E6E6FA: 'Lavendel',
		FFF: 'Hvid',
		'1ABC9C': 'Stærk cyan',
		'2ECC71': 'Smaragd',
		'3498DB': 'Klar blå',
		'9B59B6': 'Ametyst',
		'4E5F70': 'Glålig blå',
		'F1C40F': 'Klar gul',
		'16A085': 'Mørk cyan',
		'27AE60': 'Mørk smaragd',
		'2980B9': 'Stærk blå',
		'8E44AD': 'Mørk violet',
		'2C3E50': 'Mat blå',
		'F39C12': 'Orange',
		'E67E22': 'Gulerod',
		'E74C3C': 'Bleg rød',
		'ECF0F1': 'Klar sølv',
		'95A5A6': 'Lys grålig cyan',
		'DDD': 'Lys grå',
		'D35400': 'Græskar',
		'C0392B': 'Stærk rød',
		'BDC3C7': 'Sølv',
		'7F8C8D': 'Glålig cyan',
		'999': 'Mørk grå'
	},
	more: 'Flere farver...',
	panelTitle: 'Farver',
	textColorTitle: 'Tekstfarve'
} );
