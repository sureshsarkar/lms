﻿/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colorbutton', 'hr', {
	auto: 'Automatski',
	bgColorTitle: 'Boja pozadine',
	colors: {
		'000': 'Crna',
		'800000': 'Kesten',
		'8B4513': 'Smeđa',
		'2F4F4F': 'Tamno siva',
		'008080': 'Teal',
		'000080': 'Mornarska',
		'4B0082': 'Indigo',
		'696969': 'Tamno siva',
		B22222: 'Vatrena cigla',
		A52A2A: 'Smeđa',
		DAA520: 'Zlatna',
		'006400': 'Tamno zelena',
		'40E0D0': 'Tirkizna',
		'0000CD': 'Srednje plava',
		'800080': 'Ljubičasta',
		'808080': 'Siva',
		F00: 'Crvena',
		FF8C00: 'Tamno naranđasta',
		FFD700: 'Zlatna',
		'008000': 'Zelena',
		'0FF': 'Cijan',
		'00F': 'Plava',
		EE82EE: 'Ljubičasta',
		A9A9A9: 'Mutno siva',
		FFA07A: 'Svijetli losos',
		FFA500: 'Naranđasto',
		FFFF00: 'Žuto',
		'00FF00': 'Limun',
		AFEEEE: 'Blijedo tirkizna',
		ADD8E6: 'Svijetlo plava',
		DDA0DD: 'Šljiva',
		D3D3D3: 'Svijetlo siva',
		FFF0F5: 'Lavanda rumeno',
		FAEBD7: 'Antikno bijela',
		FFFFE0: 'Svijetlo žuta',
		F0FFF0: 'Med',
		F0FFFF: 'Azurna',
		F0F8FF: 'Alice plava',
		E6E6FA: 'Lavanda',
		FFF: 'Bijela',
		'1ABC9C': 'Jaka cijan',
		'2ECC71': 'Emerald',
		'3498DB': 'Svijetlo plava',
		'9B59B6': 'Ametist',
		'4E5F70': 'Sivkasto plava',
		'F1C40F': 'Žarka žuta',
		'16A085': 'Tamna cijan',
		'27AE60': 'Tamna emerald',
		'2980B9': 'Jaka plava',
		'8E44AD': 'Tamno ljubičasta',
		'2C3E50': 'Desatuirarana plava',
		'F39C12': 'Narančasta',
		'E67E22': 'Mrkva',
		'E74C3C': 'Blijedo crvena',
		'ECF0F1': 'Sjana srebrna',
		'95A5A6': 'Svijetlo sivkasta cijan',
		'DDD': 'Svijetlo siva',
		'D35400': 'Tikva',
		'C0392B': 'Jaka crvena',
		'BDC3C7': 'Srebrna',
		'7F8C8D': 'Sivkasto cijan',
		'999': 'Tamno siva'
	},
	more: 'Više boja...',
	panelTitle: 'Boje',
	textColorTitle: 'Boja teksta'
} );
